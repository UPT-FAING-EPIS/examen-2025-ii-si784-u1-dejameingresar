# Ecommerce - Aplicación de ejemplo

Proyecto monorepo con backend (.NET 8), frontend (React + Vite), Docker, Terraform y GitHub Actions.

Sigue las instrucciones en docs/README.md para levantar localmente.
