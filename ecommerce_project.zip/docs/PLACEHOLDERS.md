Replace the following placeholders after deployment:
- URL aplicación publicada: https://TU_DOMINIO
- URL repositorio: https://github.com/TU_USUARIO/ecommerce
